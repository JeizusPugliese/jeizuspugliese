import re
import tkinter as tk

class Compilador:
    def __init__(self):
        # Expresiones regulares para detectar las estructuras del lenguaje
        self.declaracion_re = re.compile(r'^[a-zA-Z_]\w*\s+(Texto|Entero|Real);$')
        self.captura_re = re.compile(r'^[a-zA-Z_]\w*\s*=\s*Capture\.(Texto|Entero|Real)\(\);$')
        self.asignacion_re = re.compile(r'^[a-zA-Z_]\w*\s*=\s*[\d+\-*/()\s]*[^\+\-\*/]\s*;$')  
        self.mensaje_re = re.compile(r'^Mensaje\.Texto\(".*?"\);$')
        
        # Diccionario para almacenar variables y sus tipos
        self.variables = {}

    def analizar_linea(self, linea):
        # Verifica la declaración de variable
        if self.declaracion_re.match(linea):
            partes = linea.split()
            nombre = partes[0].strip()
            tipo = partes[1].strip(";")
            if nombre in self.variables:
                return f"¡Nojoda! La variable '{nombre}' ya fue declarada."
            self.variables[nombre] = tipo
            return f"¡Nojoda! La variable '{nombre}' fue declarada como {tipo}."
        
        # Verifica la captura de datos
        elif self.captura_re.match(linea):
            partes = linea.split('=')
            nombre = partes[0].strip()
            tipo_captura = partes[1].split('.')[1].split('(')[0]
            
            # Verificar si la variable fue declarada
            if nombre not in self.variables:
                return f"¡Epa nojoda! La variable '{nombre}' no ha sido declarada."
            # Verificar compatibilidad de tipo
            tipo_declarado = self.variables[nombre]
            if tipo_declarado != tipo_captura:
                return f"¡Aja mira tu! '{nombre}' es {tipo_declarado} y no puede capturar {tipo_captura}."
            return f"¡Tu si sabes vale mia! La captura en '{nombre}' está buena."

        # Verifica la asignación de valores
        elif self.asignacion_re.match(linea):
            nombre, expresion = linea.split('=', 1)
            nombre = nombre.strip()
            expresion = expresion.strip(" ;")

            # Validar operadores incorrectos
            if any(op in expresion for op in ["++", "--", "**", "-*", "+*", "+-", "*-", "*+", "-+"]):
                return "¡Epa nojoda! La expresión contiene operadores inválidos."
            
            # Verificar si la variable fue declarada
            if nombre not in self.variables:
                return f"¡Epa nojoda! La variable '{nombre}' no ha sido declarada."
            # Verificar compatibilidad del tipo con la asignación
            tipo_declarado = self.variables[nombre]
            try:
                # Evaluar la expresión para determinar su tipo
                resultado = eval(expresion, {"__builtins__": {}}, {})
                if tipo_declarado == "Entero" and not isinstance(resultado, int):
                    return f"¡Aja mira tu! '{nombre}' es {tipo_declarado} y no puede tomar valores no enteros."
                elif tipo_declarado == "Real" and not isinstance(resultado, (int, float)):
                    return f"¡Aja mira tu! '{nombre}' es {tipo_declarado} y no puede tomar valores no reales."
                elif tipo_declarado == "Texto":
                    return f"¡Aja mira tu! '{nombre}' es {tipo_declarado} y no acepta operaciones matemáticas."
            except:
                return "¡Epa nojoda! Esa asignación tiene errores sintácticos."
            return f"¡Sipote vaina bacana! '{nombre}' fue asignado correctamente."

        # Verifica el mensaje de salida
        elif self.mensaje_re.match(linea):
            return "¡Jueputa que vaina bacana!"
        else:
            return "¡eche! Esa vaina está mala."

class InterfazCompilador:
    def __init__(self, root):
        self.root = root
        self.root.title("Compilador Costeñol")
        self.root.geometry("400x400")
        self.root.configure(bg="#d1f2eb")

        # Instancia del compilador
        self.compilador = Compilador()

        # Elementos de la interfaz
        self.label = tk.Label(root, text="AJA METE LA EXPRESION:", font=("Arial", 12), bg="#d1f2eb")
        self.label.pack(pady=10)

        self.text_input = tk.Text(root, height=8, width=40)
        self.text_input.pack(pady=10)

        self.compilar_button = tk.Button(root, text="COMPILAR", command=self.compilar, bg="#1abc9c", fg="white", font=("Arial", 12, "bold"))
        self.compilar_button.pack(pady=5)

        self.output_label = tk.Label(root, text="Resultado:", font=("Arial", 12, "bold"), bg="#d1f2eb")
        self.output_label.pack(pady=10)

        self.output_text = tk.Text(root, height=8, width=40, state="disabled", bg="#f8f9f9")
        self.output_text.pack(pady=10)

    def compilar(self):
        # Obtener el código ingresado por el usuario
        codigo = self.text_input.get("1.0", tk.END).strip()
        lineas = codigo.split('\n')

        # Limpiar el campo de salida
        self.output_text.config(state="normal")
        self.output_text.delete("1.0", tk.END)

        # Compilar cada línea y mostrar el resultado
        for linea in lineas:
            resultado = self.compilador.analizar_linea(linea.strip())
            self.output_text.insert(tk.END, f"{resultado}\n")

        # Deshabilitar la edición en el campo de salida
        self.output_text.config(state="disabled")

# Crear la ventana de la aplicación
root = tk.Tk()
app = InterfazCompilador(root)
root.mainloop()
