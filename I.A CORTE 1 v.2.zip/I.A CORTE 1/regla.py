

def obtener_diagnostico(pregunta):
    
    # Regla 1
    if pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "¡Te encuentras con una buena salud! "

    # Regla 2
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "tensión o sobrecarga."
    
    # Regla 3
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Rigidez ocasional ."
    
    # Regla 4
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Artritis Reumatoide."
    
    # Regla 5
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Calambres leves."
    
    # Regla 6
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Esclerosis lateral amiotrófica."
    
    # Regla 7
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Calambres recurrentes."
    
    # Regla 8
    elif pregunta['p1'] == 0 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Espasmos recurrentes."
    
    # Regla 9
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Fatiga muscular leve."
    
    # Regla 10
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Polimiositis."
    
    # Regla 11
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Síndrome de fatiga crónica."
    
    # Regla 12
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Debilidad muscular aguda."
    
    # Regla 13
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Distrofia muscular."
    
    # Regla 14
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Miastenia severa."
    
    # Regla 15
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Síndrome de fatiga crónica moderado."
    
    # Regla 16
    elif pregunta['p1'] == 0 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Síndrome de fatiga crónica avanzado."
    
    # Regla 17
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Dolor muscular leve."
    
    # Regla 18
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Tendinitis o Artritis."
    
    # Regla 19
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Rigidez muscular moderada."
    
    # Regla 20
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Rigidez muscular grave."
    
    # Regla 21
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Calambres moderados."
    
    # Regla 22
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Calambres severos."
    
    # Regla 23
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "esclerosis múltiple o la esclerosis lateral amiotrófica. "
    
    # Regla 24
    elif pregunta['p1'] == 1 and pregunta['p2'] == 0 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Artritis con fractura por estrés o osteoporosis y posible síndrome del túnel carpiano"
    
    # Regla 25
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Espasmos musculares generalizados."
    
    # Regla 26
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Distensión muscular leve."
    
    # Regla 27
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Miopatía leve."
    
    # Regla 28
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 0 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Miopatía severa."
    
    # Regla 29
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 0:
        return "Miositis moderada."
    
    # Regla 30
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 0 and pregunta['p5'] == 1:
        return "Miositis aguda"
    
    # Regla 31
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 0:
        return "Fibromialgia moderada"
    
    # Regla 32
    elif pregunta['p1'] == 1 and pregunta['p2'] == 1 and pregunta['p3'] == 1 and pregunta['p4'] == 1 and pregunta['p5'] == 1:
        return "Fibromialgia Avanzada, acude a un especialista ¡URGENTE!"
    
    # Si no se cumple ninguna de las reglas anteriores
    else:
        return "Diagnóstico no determinado, se requiere más información."
