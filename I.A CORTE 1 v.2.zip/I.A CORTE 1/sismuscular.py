
from PyQt6 import QtCore, QtGui, QtWidgets

import sys
import requests
from PyQt6.QtWidgets import QMessageBox
from regla import obtener_diagnostico

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(695, 617)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label_2 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(90, 0, 541, 21))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        
        self.label_4 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(50, 130, 401, 16))
        self.label_4.setObjectName("label_4")
        
        self.ButtonEnviar = QtWidgets.QPushButton(parent=self.centralwidget)
        self.ButtonEnviar.setGeometry(QtCore.QRect(470, 250, 75, 23))
        self.ButtonEnviar.setObjectName("ButtonEnviar")
        self.ButtonEnviar.clicked.connect(self.Enviar)
        
        self.checkBoxSi2 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxSi2.setGeometry(QtCore.QRect(510, 130, 70, 17))
        self.checkBoxSi2.setObjectName("checkBoxSi2")
        self.checkBoxNo2 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxNo2.setGeometry(QtCore.QRect(560, 130, 70, 17))
        self.checkBoxNo2.setObjectName("checkBoxNo2")
        self.checkBoxSi2.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi2, self.checkBoxNo2))
        self.checkBoxNo2.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo2, self.checkBoxSi2))
        
        self.checkBoxSi4 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxSi4.setGeometry(QtCore.QRect(510, 190, 70, 17))
        self.checkBoxSi4.setObjectName("checkBoxSi4")
        self.checkBoxNo4 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxNo4.setGeometry(QtCore.QRect(560, 190, 70, 17))
        self.checkBoxNo4.setObjectName("checkBoxNo4")
        self.checkBoxSi4.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi4, self.checkBoxNo4))
        self.checkBoxNo4.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo4, self.checkBoxSi4))
        
        self.label_9 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(50, 280, 101, 16))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label_9.setFont(font)
        self.label_9.setObjectName("label_9")
        
        self.label = QtWidgets.QLabel(parent=self.centralwidget)
        self.label.setGeometry(QtCore.QRect(140, 40, 61, 16))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        
        self.label_3 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(50, 100, 351, 16))
        self.label_3.setObjectName("label_3")
        
        self.label_11 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(370, 40, 47, 13))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label_11.setFont(font)
        self.label_11.setObjectName("label_11")
        
        self.checkBoxSi1 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxSi1.setGeometry(QtCore.QRect(510, 100, 70, 17))
        self.checkBoxSi1.setObjectName("checkBoxSi1")
        self.checkBoxNo1 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxNo1.setGeometry(QtCore.QRect(560, 100, 70, 17))
        self.checkBoxNo1.setObjectName("checkBoxNo1")
        self.checkBoxSi1.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi1, self.checkBoxNo1))
        self.checkBoxNo1.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo1, self.checkBoxSi1))
        
        self.checkBoxNo3 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxNo3.setGeometry(QtCore.QRect(560, 160, 70, 17))
        self.checkBoxNo3.setObjectName("checkBoxNo3")
        self.checkBoxSi3 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxSi3.setGeometry(QtCore.QRect(510, 160, 70, 17))
        self.checkBoxSi3.setObjectName("checkBoxSi3")
        self.checkBoxSi3.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi3, self.checkBoxNo3))
        self.checkBoxNo3.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo3, self.checkBoxSi3))
        
        self.label_8 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(50, 70, 211, 21))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_8.setFont(font)
        self.label_8.setObjectName("label_8")
        
        self.label_7 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(50, 220, 441, 16))
        self.label_7.setObjectName("label_7")
        
        self.ButtonBorrar = QtWidgets.QPushButton(parent=self.centralwidget)
        self.ButtonBorrar.setGeometry(QtCore.QRect(560, 250, 75, 23))
        self.ButtonBorrar.setObjectName("ButtonBorrar")
        self.ButtonBorrar.clicked.connect(self.clear_selection)  
        
        self.label_6 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(50, 190, 411, 16))
        self.label_6.setObjectName("label_6")
        
        self.label_5 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(50, 160, 311, 16))
        self.label_5.setObjectName("label_5")
        
        self.checkBoxSi5 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxSi5.setGeometry(QtCore.QRect(510, 217, 70, 20))
        self.checkBoxSi5.setObjectName("checkBoxSi5")
        self.checkBoxNo5 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBoxNo5.setGeometry(QtCore.QRect(560, 220, 70, 17))
        self.checkBoxNo5.setObjectName("checkBoxNo5")
        self.checkBoxSi5.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi5, self.checkBoxNo5))
        self.checkBoxNo5.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo5, self.checkBoxSi5))
        
        self.label_10 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(50, 390, 121, 16))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label_10.setFont(font)
        self.label_10.setObjectName("label_10")
        
        self.textEditNom = QtWidgets.QTextEdit(parent=self.centralwidget)
        self.textEditNom.setGeometry(QtCore.QRect(200, 40, 151, 21))
        self.textEditNom.setObjectName("textEditNom")

        self.ButtonCerrar = QtWidgets.QPushButton(parent=MainWindow)
        self.ButtonCerrar.setGeometry(QtCore.QRect(470, 520, 75, 23))
        self.ButtonCerrar.setObjectName("ButtonCerrar")
        self.ButtonCerrar.clicked.connect(MainWindow.close)
        
        self.textEditCC = QtWidgets.QTextEdit(parent=self.centralwidget)
        self.textEditCC.setGeometry(QtCore.QRect(390, 40, 151, 21))
        self.textEditCC.setObjectName("textEditCC")
        
        self.textEdit_3 = QtWidgets.QTextEdit(parent=self.centralwidget)
        self.textEdit_3.setGeometry(QtCore.QRect(50, 300, 521, 81))
        self.textEdit_3.setObjectName("textEdit_3")
        
        self.tableWidget = QtWidgets.QTableWidget(parent=self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(40, 410, 541, 111))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        
        self.ButtonConsultar = QtWidgets.QPushButton(parent=self.centralwidget)
        self.ButtonConsultar.setGeometry(QtCore.QRect(570, 540, 75, 23))
        self.ButtonConsultar.setObjectName("ButtonConsultar")
        MainWindow.setCentralWidget(self.centralwidget)
        
        self.menubar = QtWidgets.QMenuBar(parent=MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 695, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "CONSULTORIO DEL SISTEMA MUSCULAR VIRTUAL"))
        self.checkBoxSi4.setText(_translate("MainWindow", "SI"))
        self.label_4.setText(_translate("MainWindow", "2. ¿Ha notado debilidad en los músculos durante las actividades diarias?"))
        self.checkBoxNo5.setText(_translate("MainWindow", "NO"))
        self.ButtonEnviar.setText(_translate("MainWindow", "ENVIAR"))
        self.checkBoxSi2.setText(_translate("MainWindow", "SI"))
        self.checkBoxNo4.setText(_translate("MainWindow", "NO"))
        self.label_9.setText(_translate("MainWindow", "DIAGNÓSTICO"))
        self.label.setText(_translate("MainWindow", "Nombre"))
        self.checkBoxSi5.setText(_translate("MainWindow", "SI"))
        self.label_3.setText(_translate("MainWindow", "1. ¿Siente dolor muscular persistente en alguna parte del cuerpo?"))
        self.label_11.setText(_translate("MainWindow", "CC"))
        self.checkBoxNo3.setText(_translate("MainWindow", "NO"))
        self.ButtonCerrar.setText(_translate("Dialog", "CERRAR"))
        self.checkBoxSi1.setText(_translate("MainWindow", "SI"))
        self.checkBoxNo2.setText(_translate("MainWindow", "NO"))
        self.checkBoxSi3.setText(_translate("MainWindow", "SI"))
        self.label_8.setText(_translate("MainWindow", "¿QUE SINTOMAS PRESENTAS?"))
        self.label_7.setText(_translate("MainWindow", "5. ¿Ha tenido problemas para realizar movimientos normales?"))
        self.ButtonBorrar.setText(_translate("MainWindow", "BORRAR"))
        self.checkBoxNo1.setText(_translate("MainWindow", "NO"))
        self.label_6.setText(_translate("MainWindow", "4. ¿Siente rigidez muscular al despertar o después de períodos de inactividad?"))
        self.label_5.setText(_translate("MainWindow", "3. ¿Ha experimentado espasmos musculares o calambres?"))
        self.label_10.setText(_translate("MainWindow", "CONSULTAR DATOS"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "NOMBRE"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "FECHA"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "DIAGNOSTICO"))
        self.ButtonConsultar.setText(_translate("MainWindow", "CONSULTAR"))

#codigo de funciones


    def clear_selection(self):
        # Clear text fields
        self.textEditNom.clear()
        self.textEditCC.clear()
        self.textEdit_3.clear()
        
        # Uncheck all checkboxes
        self.checkBoxSi1.setChecked(False)
        self.checkBoxNo1.setChecked(False)
        self.checkBoxSi2.setChecked(False)
        self.checkBoxNo2.setChecked(False)
        self.checkBoxSi3.setChecked(False)
        self.checkBoxNo3.setChecked(False)
        self.checkBoxSi4.setChecked(False)
        self.checkBoxNo4.setChecked(False)
        self.checkBoxSi5.setChecked(False)
        self.checkBoxNo5.setChecked(False)
    
    def excluir_checkboxes(self, checkboxSi1, checkboxNo1):
        if checkboxSi1.isChecked():
            checkboxNo1.setChecked(False)
    
    def Enviar(self):
        usuario = self.textEditNom.toPlainText()
        id = self.textEditCC.toPlainText()

        pregunta = {
            'p1': 1 if self.checkBoxSi1.isChecked() else 0 if self.checkBoxNo1.isChecked() else None,
            'p2': 1 if self.checkBoxSi2.isChecked() else 0 if self.checkBoxNo2.isChecked() else None,
            'p3': 1 if self.checkBoxSi3.isChecked() else 0 if self.checkBoxNo3.isChecked() else None,
            'p4': 1 if self.checkBoxSi4.isChecked() else 0 if self.checkBoxNo4.isChecked() else None,
            'p5': 1 if self.checkBoxSi5.isChecked() else 0 if self.checkBoxNo5.isChecked() else None,
        }   
    
     #Verificar que todas las preguntas hayan sido respondidas
        if None in pregunta.values():
            QMessageBox.warning(None, 'Error', 'DEBES REPONDER TODAS LA PREGUNTAS PARA REALIZAR DIAGNOSTICO')
            return
    
        diagnostico = obtener_diagnostico(pregunta)

        data = {
            'nombre': usuario,
            'id': id,
            'pregunta_1': pregunta['p1'],
            'pregunta_2': pregunta['p2'],
            'pregunta_3': pregunta['p3'],
            'pregunta_4': pregunta['p4'],
            'pregunta_5': pregunta['p5'],
            'diagnostico': diagnostico, 
        }

        response = requests.post('http://192.168.1.4:5000/login', json=data)

        if response.status_code == 201:
            QMessageBox.information(None, 'ENVIADO', 'SE HA ENVIADO FORMULARIO')
            self.textEdit_3.setText(response.json().get('diagnostico', diagnostico))
        else:
            QMessageBox.warning(None, 'Error', 'FORMULARIO NO ENVIADO')

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec())
