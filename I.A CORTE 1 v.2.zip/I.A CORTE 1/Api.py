from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from datetime import datetime

class SistemaMuscularAPI:
    def __init__(self):
        self.app = Flask(__name__)
        self.configure_db()
        self.create_routes()

    def configure_db(self):
        # Configuración de la base de datos MySQL
        self.app.config['MYSQL_HOST'] = 'localhost'
        self.app.config['MYSQL_USER'] = 'root'
        self.app.config['MYSQL_PASSWORD'] = ''
        self.app.config['MYSQL_DB'] = 'sistema_muscular'
        self.mysql = MySQL(self.app)

    def create_routes(self):
        @self.app.route('/login', methods=['POST'])
        def login():
            cursor = self.mysql.connection.cursor()
            data = request.json

            # Verificar si el id ya existe
            cursor.execute("SELECT * FROM usuario WHERE id = %s", (data['id'],))
            existing_user = cursor.fetchone()
            
            if existing_user:
                return jsonify({"mensaje": "El usuario con ese ID ya existe"}), 400
            
            # Inserción en la tabla `usuario`
            sql_usuario = "INSERT INTO usuario (nombre, id) VALUES (%s, %s)"
            cursor.execute(sql_usuario, (data['nombre'], data['id']))
            usuario_id = cursor.lastrowid
            
            # Inserción en la tabla `preguntas`
            sql_preguntas = """
            INSERT INTO preguntas (usuario_id, pregunta_1, pregunta_2, pregunta_3, pregunta_4, pregunta_5) 
            VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql_preguntas, (usuario_id, data['pregunta_1'], data['pregunta_2'], data['pregunta_3'], data['pregunta_4'], data['pregunta_5']))
            
            # Inserción en la tabla `diagnostico`
            sql_diagnostico = "INSERT INTO diagnostico (usuario_id, id, nombre, diagnostico, fecha_registro) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(sql_diagnostico, (usuario_id, data['id'], data['nombre'], data['diagnostico'], datetime.now().date()))
            
            # Confirmar los cambios en la base de datos
            self.mysql.connection.commit()
            
            return jsonify({"mensaje": "Datos guardados correctamente"}), 201

    def run(self):
        self.app.run(debug=True, host='0.0.0.0')

if __name__ == "__main__":
    api = SistemaMuscularAPI()
    api.run()
