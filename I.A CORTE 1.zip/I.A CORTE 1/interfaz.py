from PyQt6 import QtCore, QtGui, QtWidgets
from random import choice
import sys
import requests
from PyQt6.QtWidgets import QMessageBox
from regla import diagnostico

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(661, 560)
        Dialog.setModal(False)
        self.label = QtWidgets.QLabel(parent=Dialog)
        self.label.setGeometry(QtCore.QRect(110, 50, 61, 16))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        
        self.textNombre = QtWidgets.QTextEdit(parent=Dialog)
        self.textNombre.setGeometry(QtCore.QRect(170, 50, 131, 21))
        self.textNombre.setObjectName("textNombre")
        
        self.label_2 = QtWidgets.QLabel(parent=Dialog)
        self.label_2.setGeometry(QtCore.QRect(60, 10, 541, 21))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        
        self.label_3 = QtWidgets.QLabel(parent=Dialog)
        self.label_3.setGeometry(QtCore.QRect(20, 110, 351, 16))
        self.label_3.setObjectName("label_3")
        
        self.label_4 = QtWidgets.QLabel(parent=Dialog)
        self.label_4.setGeometry(QtCore.QRect(20, 140, 401, 16))
        self.label_4.setObjectName("label_4")
        
        self.label_5 = QtWidgets.QLabel(parent=Dialog)
        self.label_5.setGeometry(QtCore.QRect(20, 170, 311, 16))
        self.label_5.setObjectName("label_5")
        
        self.label_6 = QtWidgets.QLabel(parent=Dialog)
        self.label_6.setGeometry(QtCore.QRect(20, 200, 411, 16))
        self.label_6.setObjectName("label_6")
        
        self.label_7 = QtWidgets.QLabel(parent=Dialog)
        self.label_7.setGeometry(QtCore.QRect(20, 230, 441, 16))
        self.label_7.setObjectName("label_7")
        
        self.label_8 = QtWidgets.QLabel(parent=Dialog)
        self.label_8.setGeometry(QtCore.QRect(20, 80, 211, 21))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_8.setFont(font)
        self.label_8.setObjectName("label_8")
        
        self.label_9 = QtWidgets.QLabel(parent=Dialog)
        self.label_9.setGeometry(QtCore.QRect(20, 290, 101, 16))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label_9.setFont(font)
        self.label_9.setObjectName("label_9")
        
        self.label_10 = QtWidgets.QLabel(parent=Dialog)
        self.label_10.setGeometry(QtCore.QRect(20, 400, 121, 16))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label_10.setFont(font)
        self.label_10.setObjectName("label_10")
        
        self.ButtonEnviar = QtWidgets.QPushButton(parent=Dialog)
        self.ButtonEnviar.setGeometry(QtCore.QRect(440, 260, 75, 23))
        self.ButtonEnviar.setObjectName("ButtonEnviar")
        self.ButtonEnviar.clicked.connect(self.Enviar)

        self.ButtonBorrar = QtWidgets.QPushButton(parent=Dialog)
        self.ButtonBorrar.setGeometry(QtCore.QRect(530, 260, 75, 23))
        self.ButtonBorrar.setObjectName("ButtonBorrar")
        self.ButtonBorrar.clicked.connect(self.clear_selection)  

        self.label_11 = QtWidgets.QLabel(parent=Dialog)
        self.label_11.setGeometry(QtCore.QRect(340, 50, 47, 13))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setBold(True)
        font.setWeight(75)
        self.label_11.setFont(font)
        self.label_11.setObjectName("label_11")
        
        self.textDiagnostico = QtWidgets.QTextEdit(parent=Dialog)
        self.textDiagnostico.setGeometry(QtCore.QRect(20, 310, 461, 81))
        self.textDiagnostico.setObjectName("textDiagnostico")
        
        self.textID = QtWidgets.QTextEdit(parent=Dialog)
        self.textID.setGeometry(QtCore.QRect(360, 50, 151, 21))
        self.textID.setObjectName("textID")
        
        self.ButtonCerrar = QtWidgets.QPushButton(parent=Dialog)
        self.ButtonCerrar.setGeometry(QtCore.QRect(470, 520, 75, 23))
        self.ButtonCerrar.setObjectName("ButtonCerrar")
        self.ButtonCerrar.clicked.connect(Dialog.close)

        self.label_12 = QtWidgets.QLabel(parent=Dialog)
        self.label_12.setGeometry(QtCore.QRect(20, 540, 47, 13))
        self.label_12.setObjectName("label_12")


        self.checkBoxSi1 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxSi1.setGeometry(QtCore.QRect(480, 110, 70, 17))
        self.checkBoxSi1.setObjectName("checkBoxSi1")
        self.checkBoxNo1 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxNo1.setGeometry(QtCore.QRect(530, 110, 70, 17))
        self.checkBoxNo1.setObjectName("checkBoxNo1")
        self.checkBoxSi1.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi1, self.checkBoxNo1))
        self.checkBoxNo1.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo1, self.checkBoxSi1))

        self.checkBoxSi2 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxSi2.setGeometry(QtCore.QRect(480, 140, 70, 17))
        self.checkBoxSi2.setObjectName("checkBoxSi2")
        self.checkBoxNo2 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxNo2.setGeometry(QtCore.QRect(530, 140, 70, 17))
        self.checkBoxNo2.setObjectName("checkBoxNo2")
        self.checkBoxSi2.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi2, self.checkBoxNo2))
        self.checkBoxNo2.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo2, self.checkBoxSi2))
        
        self.checkBoxSi3 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxSi3.setGeometry(QtCore.QRect(480, 170, 70, 17))
        self.checkBoxSi3.setObjectName("checkBoxSi3")
        self.checkBoxNo3 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxNo3.setGeometry(QtCore.QRect(530, 170, 70, 17))
        self.checkBoxNo3.setObjectName("checkBoxNo3")
        self.checkBoxSi3.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi2, self.checkBoxNo3))
        self.checkBoxNo3.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo3, self.checkBoxSi3))
       
        self.checkBoxSi4 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxSi4.setGeometry(QtCore.QRect(480, 200, 70, 17))
        self.checkBoxSi4.setObjectName("checkBoxSi4")
        self.checkBoxNo4 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxNo4.setGeometry(QtCore.QRect(530, 200, 70, 17))
        self.checkBoxNo4.setObjectName("checkBoxNo4")
        self.checkBoxSi4.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi3, self.checkBoxNo3))
        self.checkBoxNo4.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo3, self.checkBoxSi3))

        self.checkBoxSi5 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxSi5.setGeometry(QtCore.QRect(480, 227, 70, 20))
        self.checkBoxSi5.setObjectName("checkBoxSi5")
        self.checkBoxNo5 = QtWidgets.QCheckBox(parent=Dialog)
        self.checkBoxNo5.setGeometry(QtCore.QRect(530, 230, 70, 17))
        self.checkBoxNo5.setObjectName("checkBoxNo5")
        self.checkBoxSi5.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxSi5, self.checkBoxNo5))
        self.checkBoxNo5.toggled.connect(lambda: self.excluir_checkboxes(self.checkBoxNo5, self.checkBoxSi5))



        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def clear_selection(self):
        # Clear text fields
        self.textNombre.clear()
        self.textID.clear()
        self.textDiagnostico.clear()
        self.textRecomendacion.clear()
        
        # Uncheck all checkboxes
        self.checkBoxSi1.setChecked(False)
        self.checkBoxNo1.setChecked(False)
        self.checkBoxSi2.setChecked(False)
        self.checkBoxNo2.setChecked(False)
        self.checkBoxSi3.setChecked(False)
        self.checkBoxNo3.setChecked(False)
        self.checkBoxSi4.setChecked(False)
        self.checkBoxNo4.setChecked(False)
        self.checkBoxSi5.setChecked(False)
        self.checkBoxNo5.setChecked(False)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "Nombre"))
        self.label_2.setText(_translate("Dialog", "CONSULTORIO DEL SISTEMA MUSCULAR VIRTUAL"))
        self.label_3.setText(_translate("Dialog", "1. ¿Siente dolor muscular persistente en alguna parte del cuerpo?"))
        self.label_4.setText(_translate("Dialog", "2. ¿Ha notado debilidad en los músculos durante las actividades diarias?"))
        self.label_5.setText(_translate("Dialog", "3. ¿Ha experimentado espasmos musculares o calambres?"))
        self.label_6.setText(_translate("Dialog", "4. ¿Siente rigidez muscular al despertar o después de períodos de inactividad?"))
        self.label_7.setText(_translate("Dialog", "5. ¿Ha tenido problemas para realizar movimientos normales?"))
        self.label_8.setText(_translate("Dialog", "¿QUE SINTOMAS PRESENTAS?"))
        self.label_9.setText(_translate("Dialog", "DIAGNÓSTICO"))
        self.ButtonEnviar.setText(_translate("Dialog", "ENVIAR"))
        self.ButtonBorrar.setText(_translate("Dialog", "BORRAR"))
        self.label_11.setText(_translate("Dialog", "ID"))
        self.textDiagnostico.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.textID.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.ButtonCerrar.setText(_translate("Dialog", "CERRAR"))
        self.label_12.setText(_translate("Dialog", "JDY"))
        self.checkBoxSi1.setText(_translate("Dialog", "SI"))
        self.checkBoxNo1.setText(_translate("Dialog", "NO"))
        self.checkBoxSi2.setText(_translate("Dialog", "SI"))
        self.checkBoxNo2.setText(_translate("Dialog", "NO"))
        self.checkBoxSi3.setText(_translate("Dialog", "SI"))
        self.checkBoxNo3.setText(_translate("Dialog", "NO"))
        self.checkBoxSi4.setText(_translate("Dialog", "SI"))
        self.checkBoxNo4.setText(_translate("Dialog", "NO"))
        self.checkBoxSi5.setText(_translate("Dialog", "SI"))
        self.checkBoxNo5.setText(_translate("Dialog", "NO"))

       
        
       
    def excluir_checkboxes(self, checkbox_1, checkbox_2):
        if checkbox_1.isChecked():
            checkbox_2.setChecked(False)
    
    def Enviar(self):
        usuario= self.textNombre.toPlainText()
        id= self.textID.toPlainText()
        
        pregunta = {
            'p1': 1 if self.checkBoxSi1.isChecked() else 0 if self.checkBoxNo1.isChecked() else None,
            'p2': 1 if self.checkBoxSi2.isChecked() else 0 if self.checkBoxNo2.isChecked() else None,
            'p3': 1 if self.checkBoxSi3.isChecked() else 0 if self.checkBoxNo3.isChecked() else None,
            'p4': 1 if self.checkBoxSi4.isChecked() else 0 if self.checkBoxNo4.isChecked() else None,
            'p5': 1 if self.checkBoxSi5.isChecked() else 0 if self.checkBoxNo5.isChecked() else None,
        }   
    
     #Verificar que todas las preguntas hayan sido respondidas
        if None in pregunta.values():
            QMessageBox.warning(None, 'Error', 'Por favor, responda todas las preguntas antes de enviar el formulario.')
            return
    
        diagnostico_result = diagnostico(pregunta)
        data = {
            'usuario': usuario,
            'id': id,
            'pregunta1': pregunta['p1'],
            'pregunta2': pregunta['p2'],
            'pregunta3': pregunta['p3'],
            'pregunta4': pregunta['p4'],
            'pregunta5': pregunta['p5'],
            'diagnostico': diagnostico_result, 
        }

        response = requests.post('http://192.168.18.22:5000/guardar_datos', json=data)

        if response.status_code == 201:
            QMessageBox.information(None, 'Éxito', 'Formulario enviado exitosamente.')
            self.textEdit.setText(response.json().get('diagnostico', diagnostico_result))
        else:
            QMessageBox.warning(None, 'Error', 'Hubo un problema al enviar el formulario.')

            self.ButtonCerrar.clicked.connect(self.Dialog.close)  
    


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec())
