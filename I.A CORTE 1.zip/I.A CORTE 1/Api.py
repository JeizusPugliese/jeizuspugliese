from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from datetime import datetime

app = Flask(__name__)


app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'sistema_muscular'


mysql = MySQL(app)


@app.route('/login', methods=['POST'])
def login():
        cursor = mysql.connection.cursor()
        data = request.json
        
        
        sql_usuario = "INSERT INTO usuario (nombre, id) VALUES (%s, %s)"
        cursor.execute(sql_usuario, (data['nombre'],data['id']))
        usuario_id = cursor.lastrowid
        
        
        sql_preguntas = """
        INSERT INTO preguntas (usuario_id, pregunta1, pregunta2, pregunta3, pregunta4, pregunta5) 
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(sql_preguntas, (usuario_id, data['pregunta1'], data['pregunta2'], data['pregunta3'], data['pregunta4'], data['pregunta5']))
        
    
        sql_diagnostico = "INSERT INTO diagnostico (usuario_id, diagnostico, fecha) VALUES (%s, %s, %s)"
        cursor.execute(sql_diagnostico, (usuario_id, data['diagnostico'], datetime.now().date()))
        
        app.commit()
        
        return jsonify({"mensaje": "Datos guardados correctamente"}), 201
    

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')