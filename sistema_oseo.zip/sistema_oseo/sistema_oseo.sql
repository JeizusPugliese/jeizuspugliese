-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2024 at 05:42 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistema_oseo`
--

-- --------------------------------------------------------

--
-- Table structure for table `diagnostico`
--

CREATE TABLE `diagnostico` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `diagnostico` varchar(300) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `dni` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diagnostico`
--

INSERT INTO `diagnostico` (`id`, `usuario_id`, `diagnostico`, `fecha`, `nombre`, `dni`) VALUES
(1, 17, 'Artritis reumatoide o artrosis avanzada con fractura por estrés o osteoporosis y posible síndrome del túnel carpiano', '2024-08-21', NULL, NULL),
(2, 18, 'Usted esta sano.', '2024-08-21', NULL, NULL),
(3, 19, 'Artrosis con fractura por estrés o osteoporosis', '2024-08-21', NULL, NULL),
(4, 20, 'Artritis reumatoide o artrosis avanzada con fractura por estrés o osteoporosis y posible síndrome del túnel carpiano', '2024-08-22', 'jesus', '1222'),
(5, 21, 'Artritis con riesgo de fracturas y posible síndrome del túnel carpiano', '2024-08-22', 'jesus', '1233455'),
(6, 22, 'Usted esta sano.', '2024-08-23', 'elisabeth', '2022333');

-- --------------------------------------------------------

--
-- Table structure for table `respuestas`
--

CREATE TABLE `respuestas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `pregunta1` tinyint(1) DEFAULT NULL,
  `pregunta2` tinyint(1) DEFAULT NULL,
  `pregunta3` tinyint(1) DEFAULT NULL,
  `pregunta4` tinyint(1) DEFAULT NULL,
  `pregunta5` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `respuestas`
--

INSERT INTO `respuestas` (`id`, `usuario_id`, `pregunta1`, `pregunta2`, `pregunta3`, `pregunta4`, `pregunta5`) VALUES
(1, 1, 1, 0, 1, 0, 1),
(2, 3, 1, 0, 1, 0, 1),
(3, 4, 1, 0, 1, 0, 1),
(4, 5, 1, 1, 0, 1, 1),
(5, 6, 0, 0, 0, 0, 0),
(6, 7, 0, 0, 0, 0, 0),
(7, 8, 1, 1, 1, 1, 1),
(8, 9, 1, 1, 1, 1, 1),
(9, 10, 1, 1, 1, 1, 1),
(10, 11, 1, 1, 1, 1, 1),
(11, 12, 1, 1, 1, 1, 0),
(12, 13, 1, 0, 0, 1, 0),
(13, 14, 1, 0, 0, 1, 0),
(14, 15, 0, 0, 0, 0, 0),
(15, 16, 1, 1, 1, 1, 1),
(16, 17, 1, 1, 1, 1, 1),
(17, 18, 0, 0, 0, 0, 0),
(18, 19, 0, 1, 1, 1, 0),
(19, 20, 1, 1, 1, 1, 1),
(20, 21, 1, 0, 1, 0, 1),
(21, 22, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `dni` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `dni`) VALUES
(1, 'jesus', ''),
(3, 'jesus1', '1222020'),
(4, 'jizu', '123'),
(5, 'orlando vz', '349545478'),
(6, 'jailene', '34578'),
(7, 'jailene2', '1344'),
(8, 'jailene2', '1344'),
(9, 'jailene2', '1344'),
(10, 'jailene2', '1344'),
(11, 'jailene2', '1344'),
(12, 'jailened', '1344'),
(13, 'jailened', '1344'),
(14, 'jailened', '1344'),
(15, 'jailened', '1344'),
(16, 'jailened', '1344'),
(17, 'jailened', '1344'),
(18, 'jailened', '1344'),
(19, 'jailened', '1344'),
(20, 'jesus', '1222'),
(21, 'jesus', '1233455'),
(22, 'elisabeth', '2022333');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indexes for table `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diagnostico`
--
ALTER TABLE `diagnostico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `respuestas`
--
ALTER TABLE `respuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD CONSTRAINT `diagnostico_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`);

--
-- Constraints for table `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
