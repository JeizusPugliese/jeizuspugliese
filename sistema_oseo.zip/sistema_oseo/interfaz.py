import sys
import requests
from PyQt6.QtWidgets import QMessageBox

from PyQt6 import QtCore, QtGui, QtWidgets

from sistema_regla import obtener_diagnostico


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(838, 600)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(parent=self.centralwidget)
        self.label.setGeometry(QtCore.QRect(220, 60, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_3 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(440, 60, 21, 16))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.lineEdit = QtWidgets.QLineEdit(parent=self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(290, 60, 113, 20))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_2 = QtWidgets.QLineEdit(parent=self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(470, 60, 113, 20))
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.label_4 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(40, 140, 380, 21))
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(40, 170, 380, 21))
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(40, 115, 380, 16))
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(40, 230, 400, 16))
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(40, 200, 380, 16))
        self.label_8.setObjectName("label_8")
        self.pushButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(440, 260, 71, 31))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(530, 260, 71, 31))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_5 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton_5.setGeometry(QtCore.QRect(620, 310, 121, 31))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_5.setText("Consultar Diagnóstico")
        self.pushButton_5.clicked.connect(self.consultar_diagnostico)
        self.tableWidget = QtWidgets.QTableWidget(parent=self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(30, 450, 800, 100))
        self.tableWidget.setColumnCount(3)  
        self.tableWidget.setHorizontalHeaderLabels(['Fecha', 'Nombre', 'Diagnóstico'])
        self.tableWidget.setColumnWidth(2, 650) 
        self.tableWidget.setObjectName("tableWidget")
        self.label_9 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(220, 10, 461, 21))
        font = QtGui.QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.label_9.setFont(font)
        self.label_9.setObjectName("label_9")
        self.label_2 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(30, 340, 101, 16))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.textEdit = QtWidgets.QTextEdit(parent=self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(30, 360, 371, 71))
        self.textEdit.setObjectName("textEdit")
        self.textEdit.setReadOnly(True)  # Hacer que el textEdit no sea editable
        self.pushButton_3 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(750, 555, 75, 23))
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.label_11 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(40, 90, 201, 16))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_11.setFont(font)
        self.label_11.setObjectName("label_11")
        self.pushButton_4 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton_4.clicked.connect(self.enviar_formulario)
        self.pushButton_4.setGeometry(QtCore.QRect(620, 260, 121, 31))
        self.pushButton_4.setObjectName("pushButton_4")
        self.checkBox = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox.setGeometry(QtCore.QRect(435, 110, 70, 17))
        self.checkBox.setObjectName("checkBox")
        self.checkBox_2 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_2.setGeometry(QtCore.QRect(520, 110, 70, 17))
        self.checkBox_2.setObjectName("checkBox_2")
        self.checkBox_3 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_3.setGeometry(QtCore.QRect(435, 140, 70, 17))
        self.checkBox_3.setObjectName("checkBox_3")
        self.checkBox_4 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_4.setGeometry(QtCore.QRect(520, 140, 70, 17))
        self.checkBox_4.setObjectName("checkBox_4")
        self.checkBox_5 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_5.setGeometry(QtCore.QRect(435, 170, 70, 17))
        self.checkBox_5.setObjectName("checkBox_5")
        self.checkBox_6 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_6.setGeometry(QtCore.QRect(520, 170, 70, 17))
        self.checkBox_6.setObjectName("checkBox_6")
        self.checkBox_7 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_7.setGeometry(QtCore.QRect(435, 200, 70, 17))
        self.checkBox_7.setObjectName("checkBox_7")
        self.checkBox_8 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_8.setGeometry(QtCore.QRect(520, 200, 70, 17))
        self.checkBox_8.setObjectName("checkBox_8")
        self.checkBox_9 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_9.setGeometry(QtCore.QRect(435, 230, 70, 17))
        self.checkBox_9.setObjectName("checkBox_9")
        self.checkBox_10 = QtWidgets.QCheckBox(parent=self.centralwidget)
        self.checkBox_10.setGeometry(QtCore.QRect(520, 230, 70, 17))
        self.checkBox_10.setObjectName("checkBox_10")

        
        self.checkBox.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox, self.checkBox_2))
        self.checkBox_2.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_2, self.checkBox))
        self.checkBox_3.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_3, self.checkBox_4))
        self.checkBox_4.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_4, self.checkBox_3))
        self.checkBox_5.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_5, self.checkBox_6))
        self.checkBox_6.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_6, self.checkBox_5))
        self.checkBox_7.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_7, self.checkBox_8))
        self.checkBox_8.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_8, self.checkBox_7))
        self.checkBox_9.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_9, self.checkBox_10))
        self.checkBox_10.toggled.connect(lambda: self.excluir_checkboxes(self.checkBox_10, self.checkBox_9))

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # deshabilitar checkboxes al guardar
        self.pushButton_2.clicked.connect(self.deshabilitar_checkboxes)
        # Borrar respuestas 
        self.pushButton.clicked.connect(self.borrar_respuestas)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Nombre"))
        self.label_3.setText(_translate("MainWindow", "DNI"))
        self.label_4.setText(_translate("MainWindow", "2. ¿Sientes dolor en las articulaciones después de la actividad física?"))
        self.label_5.setText(_translate("MainWindow", "3. ¿Has tenido un historial de fracturas o lesiones óseas frecuentes?"))
        self.label_6.setText(_translate("MainWindow", "1. ¿Sientes dolor en las articulaciones?"))
        self.label_7.setText(_translate("MainWindow", "5. ¿Notas pérdida de fuerza en tus manos o dificultad para agarrar objetos?"))
        self.label_8.setText(_translate("MainWindow", "4. ¿Experimentas dolor en el talón o en la planta del pie al caminar?"))
        self.pushButton.setText(_translate("MainWindow", "Borrar"))
        self.pushButton_2.setText(_translate("MainWindow", "Guardar"))
        self.label_9.setText(_translate("MainWindow", "CONSULTORIO MEDICO DEL SISTEMA OSEO"))
        self.label_2.setText(_translate("MainWindow", "DIAGNOSTICO:"))
        self.pushButton_3.setText(_translate("MainWindow",  "SALIR"))
        self.label_11.setText(_translate("MainWindow", "Diagnóstico de enfermedades"))
        self.pushButton_4.setText(_translate("MainWindow", "Enviar Formulario"))
        self.checkBox.setText(_translate("MainWindow", "Sí"))
        self.checkBox_2.setText(_translate("MainWindow", "No"))
        self.checkBox_3.setText(_translate("MainWindow", "Sí"))
        self.checkBox_4.setText(_translate("MainWindow", "No"))
        self.checkBox_5.setText(_translate("MainWindow", "Sí"))
        self.checkBox_6.setText(_translate("MainWindow", "No"))
        self.checkBox_7.setText(_translate("MainWindow", "Sí"))
        self.checkBox_8.setText(_translate("MainWindow", "No"))
        self.checkBox_9.setText(_translate("MainWindow", "Sí"))
        self.checkBox_10.setText(_translate("MainWindow", "No"))

        self.pushButton_3.clicked.connect(MainWindow.close)

    def consultar_diagnostico(self):

        
        response = requests.get('http://192.168.1.4:5000/consultar_diagnosticos')

        if response.status_code == 200:
            resultados = response.json()

            
            if resultados:
                
                self.tableWidget.setRowCount(len(resultados)) 

                for row, resultado in enumerate(resultados):
                    self.tableWidget.setItem(row, 0, QtWidgets.QTableWidgetItem(resultado['fecha']))
                    self.tableWidget.setItem(row, 1, QtWidgets.QTableWidgetItem(resultado['nombre']))
                    self.tableWidget.setItem(row, 2, QtWidgets.QTableWidgetItem(resultado['diagnostico']))
            else:
                QMessageBox.information(None, 'Sin resultados')
        else:
            QMessageBox.warning(None, 'Error', 'Hubo un problema al consultar el diagnóstico.')




    def deshabilitar_checkboxes(self):
        # deshabilitar todos los checkboxes
        for checkbox in [self.checkBox, self.checkBox_2, self.checkBox_3, self.checkBox_4,
                         self.checkBox_5, self.checkBox_6, self.checkBox_7, self.checkBox_8,
                         self.checkBox_9, self.checkBox_10]:
            checkbox.setEnabled(False)

    def borrar_respuestas(self):
        # habilitar todos los checkboxes y desmarcarlos
        for checkbox in [self.checkBox, self.checkBox_2, self.checkBox_3, self.checkBox_4,
                         self.checkBox_5, self.checkBox_6, self.checkBox_7, self.checkBox_8,
                         self.checkBox_9, self.checkBox_10]:
            checkbox.setEnabled(True)
            checkbox.setChecked(False)

    def excluir_checkboxes(self, checkbox1, checkbox2):
        # desmarcar el checkbox opuesto si uno está marcado
        if checkbox1.isChecked():
            checkbox2.setChecked(False)

    def enviar_formulario(self):
        nombre = self.lineEdit.text()
        dni = self.lineEdit_2.text()

        respuestas = {
            'p1': 1 if self.checkBox.isChecked() else 0 if self.checkBox_2.isChecked() else None,
            'p2': 1 if self.checkBox_3.isChecked() else 0 if self.checkBox_4.isChecked() else None,
            'p3': 1 if self.checkBox_5.isChecked() else 0 if self.checkBox_6.isChecked() else None,
            'p4': 1 if self.checkBox_7.isChecked() else 0 if self.checkBox_8.isChecked() else None,
            'p5': 1 if self.checkBox_9.isChecked() else 0 if self.checkBox_10.isChecked() else None,
        }

        # verificar que todas las preguntas hayan sido respondidas
        if None in respuestas.values():
            QMessageBox.warning(None, 'Error', 'Por favor, responda todas las preguntas antes de enviar el formulario.')
            return
        
        diagnostico = obtener_diagnostico(respuestas)

        data = {
            'nombre': nombre,
            'dni': dni,
            'pregunta1': respuestas['p1'],
            'pregunta2': respuestas['p2'],
            'pregunta3': respuestas['p3'],
            'pregunta4': respuestas['p4'],
            'pregunta5': respuestas['p5'],
            'diagnostico': diagnostico, 
        }

        response = requests.post('http://192.168.1.4:5000/guardar_datos', json=data)

        if response.status_code == 201:
            QMessageBox.information(None, 'Éxito', 'Formulario enviado exitosamente.')
            self.textEdit.setText(response.json().get('diagnostico', diagnostico))
        else:
            QMessageBox.warning(None, 'Error', 'Hubo un problema al enviar el formulario.')



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec())
