from flask import Flask, request, jsonify
import mysql.connector
from datetime import datetime

class SistemaOseoAPI:
    def __init__(self):
        self.app = Flask(__name__)
        self.db = mysql.connector.connect(
            host="localhost",
            user="root",  
            password="",  
            database="sistema_oseo"
        )
        self.cursor = self.db.cursor()
        self.setup_routes()

    def setup_routes(self):
        self.app.add_url_rule('/guardar_datos', view_func=self.guardar_datos, methods=['POST'])
        self.app.add_url_rule('/consultar_diagnosticos', view_func=self.consultar_diagnosticos, methods=['GET'])

    def guardar_datos(self):
        data = request.json
        
        # Insertar datos en la tabla 'usuario'
        sql_usuario = "INSERT INTO usuario (nombre, dni) VALUES (%s, %s)"
        self.cursor.execute(sql_usuario, (data['nombre'], data['dni']))
        usuario_id = self.cursor.lastrowid
        
        # Insertar respuestas en la tabla 'respuestas'
        sql_respuestas = """
        INSERT INTO respuestas (usuario_id, pregunta1, pregunta2, pregunta3, pregunta4, pregunta5) 
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        self.cursor.execute(sql_respuestas, (
            usuario_id, data['pregunta1'], data['pregunta2'], data['pregunta3'], 
            data['pregunta4'], data['pregunta5']
        ))
        
        # Insertar diagnóstico en la tabla 'diagnostico'
        sql_diagnostico = """
        INSERT INTO diagnostico (usuario_id, nombre, dni, diagnostico, fecha) 
        VALUES (%s, %s, %s, %s, %s)
        """
        self.cursor.execute(sql_diagnostico, (
            usuario_id, data['nombre'], data['dni'], 
            data['diagnostico'], datetime.now().date()
        ))
        
        self.db.commit()
        
        return jsonify({"mensaje": "Datos guardados correctamente"}), 201

    def consultar_diagnosticos(self):
        sql = """
        SELECT nombre, dni, diagnostico, fecha 
        FROM diagnostico
        """
        self.cursor.execute(sql)
        resultados = self.cursor.fetchall()
        
        diagnosticos = []
        for resultado in resultados:
            diagnosticos.append({
                'nombre': resultado[0],
                'dni': resultado[1],
                'diagnostico': resultado[2],
                'fecha': resultado[3].strftime('%Y-%m-%d')
            })
        
        return jsonify(diagnosticos), 200

    def run(self):
        self.app.run(host='0.0.0.0', port=5000, debug=True)


if __name__ == '__main__':
    api = SistemaOseoAPI()
    api.run()

