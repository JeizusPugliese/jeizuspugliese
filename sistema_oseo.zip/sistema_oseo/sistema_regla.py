

def obtener_diagnostico(respuestas):
    

    # Regla 1
    if respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Usted esta sano."

    # Regla 2
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Síndrome del túnel carpiano."
    
    # Regla 3
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Fascitis plantar."
    
    # Regla 4
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Fascitis plantar con posible síndrome del túnel carpiano."
    
    # Regla 5
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Riesgo de fracturas (posible osteoporosis)."
    
    # Regla 6
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Riesgo de fracturas con posible síndrome del túnel carpiano."
    
    # Regla 7
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Fractura por estrés o osteoporosis"
    
    # Regla 8
    elif respuestas['p1'] == 0 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Fractura por estrés o osteoporosis con posible síndrome del túnel carpiano."
    
    # Regla 9
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Artrosis leve"
    
    # Regla 10
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Artrosis leve con posible síndrome del túnel carpiano"
    
    # Regla 11
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Artrosis leve con fascitis plantar"
    
    # Regla 12
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Artrosis leve con fascitis plantar y posible síndrome del túnel carpiano"
    
    # Regla 13
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Artrosis con riesgo de fracturas"
    
    # Regla 14
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Artrosis con riesgo de fracturas y posible síndrome del túnel carpiano"
    
    # Regla 15
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Artrosis con fractura por estrés o osteoporosis"
    
    # Regla 16
    elif respuestas['p1'] == 0 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Artrosis con fractura por estrés o osteoporosis y posible síndrome del túnel carpiano"
    
    # Regla 17
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Artritis leve"
    
    # Regla 18
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Artritis leve con posible síndrome del túnel carpiano"
    
    # Regla 19
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Artritis leve con fascitis plantar"
    
    # Regla 20
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Artritis leve con fascitis plantar y posible síndrome del túnel carpiano"
    
    # Regla 21
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Artritis con riesgo de fracturas"
    
    # Regla 22
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Artritis con riesgo de fracturas y posible síndrome del túnel carpiano"
    
    # Regla 23
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Artritis con fractura por estrés o osteoporosis"
    
    # Regla 24
    elif respuestas['p1'] == 1 and respuestas['p2'] == 0 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Artritis con fractura por estrés o osteoporosis y posible síndrome del túnel carpiano"
    
    # Regla 25
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Artritis reumatoide o artrosis avanzada"
    
    # Regla 26
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Artritis reumatoide o artrosis avanzada con posible síndrome del túnel carpiano"
    
    # Regla 27
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Artritis reumatoide o artrosis avanzada con fascitis plantar"
    
    # Regla 28
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 0 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Artritis reumatoide o artrosis avanzada con fascitis plantar y posible síndrome del túnel carpiano"
    
    # Regla 29
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 0:
        return "Artritis reumatoide o artrosis avanzada con riesgo de fracturas"
    
    # Regla 30
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 0 and respuestas['p5'] == 1:
        return "Artritis reumatoide o artrosis avanzada con riesgo de fracturas y posible síndrome del túnel carpiano"
    
    # Regla 31
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 0:
        return "Artritis reumatoide o artrosis avanzada con fractura por estrés o osteoporosis"
    
    # Regla 32
    elif respuestas['p1'] == 1 and respuestas['p2'] == 1 and respuestas['p3'] == 1 and respuestas['p4'] == 1 and respuestas['p5'] == 1:
        return "Artritis reumatoide o artrosis avanzada con fractura por estrés o osteoporosis y posible síndrome del túnel carpiano"
    else:
        return "Diagnóstico: No se encontró coincidencia con las reglas."

