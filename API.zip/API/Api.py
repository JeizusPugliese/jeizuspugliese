from flask import Flask, request, jsonify
from flask_mysqldb import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'proyecto'

mysql = MySQL(app)

@app.route('/login', methods=['POST'])
def login():
    try:
        if request.method == 'POST' and 'Email' in request.json and 'Pass' in request.json:
            email = request.json['Email']
            password = request.json['Pass']

            cur = mysql.connection.cursor()
            cur.execute("SELECT * FROM usuarios WHERE Correo = %s AND Contraseña = %s", (email, password))
            user = cur.fetchone()
            cur.close()

            if user:
                return jsonify({'message': 'Inicio de sesión exitoso', 'ID de usuario': user[0]}), 200
            else:
                return jsonify({'error': 'Credenciales incorrectas'}), 401
        else:
            return jsonify({'error': 'Debe llenar todos los campos'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')