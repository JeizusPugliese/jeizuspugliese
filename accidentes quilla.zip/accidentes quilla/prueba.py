class Rol(Models):
    nombre = models.CharField(max_length=100, unique=True, null=False)

    def _str_(self):
        return self.nombre


class Usuario(AbstractUser):
    primer_nombre = models.CharField(max_length=50, null=False)
    segundo_nombre = models.CharField(max_length=50, null=True, blank=True)
    primer_apellido = models.CharField(max_length=50, null=False)
    segundo_apellido = models.CharField(max_length=50, null=False)
    rol = models.ForeignKey(Rol, on_delete=models.CASCADE, null=True)

    def _str_(self):
        segundo_nombre = self.segundo_nombre if self.segundo_nombre else ""

        return f"{self.primer_nombre} {segundo_nombre} {self.primer_apellido} {self.segundo_apellido}"


class Zona(Models):
    nombre = models.CharField(max_length=100, unique=True, null=False)

    def _str_(self):
        return self.nombre


class Barrio(Models):
    nombre = models.CharField(max_length=100, unique=True, null=False)
    zona = models.ForeignKey(Zona, on_delete=models.CASCADE)

    def _str_(self):
        return f"{self.nombre} - {self.zona}"


class TipoVia(Models):
    nombre = models.CharField(max_length=100, unique=True, null=False)

    def _str_(self):
        return self.nombre


class Via(Models):
    tipo_via = models.ForeignKey(TipoVia, on_delete=models.CASCADE)
    numero_via = models.CharField(max_length=5, null=True, blank=True)
    nombre_via = models.CharField(max_length=50, null=True, blank=True)
    sufijo_via = models.CharField(max_length=10, null=True, blank=True)

    def _str_(self):
        numero_via = self.numero_via if self.numero_via else ""
        nombre_via = self.nombre_via if self.nombre_via else ""
        sufijo_via = self.sufijo_via if self.sufijo_via else ""

        return f"{self.tipo_via} {numero_via} {nombre_via} {sufijo_via}"


class Ubicacion(Models):
    primer_via = models.ForeignKey(Via, on_delete=models.CASCADE, related_name="ubicaciones_primer_via", null=False)
    segunda_via = models.ForeignKey(Via, on_delete=models.CASCADE, related_name="ubicaciones_segunda_via", null=True, blank=True)
    latitud = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitud = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    barrio = models.ForeignKey(Barrio, on_delete=models.CASCADE, null=True, blank=True)
    complemento = models.CharField(max_length=256, null=True, blank=True)

    def _str_(self):
        return


class CondicionVictima(Models):
    rol_victima = models.CharField(max_length=100, unique=True, null=False)

    def _str_(self):
        return self.rol_victima


class GravedadVictima(Models):
    nivel_gravedad = models.CharField(max_length=100, unique=True, null=False)

    def _str_(self):
        return self.nivel_gravedad


class TipoAccidente(Models):
    tipo = models.CharField(max_length=100, unique=True, null=False)

    def _str_(self):
        return self.tipo


class Accidente(Models):
    fecha = models.DateField(null=False)
    ubicacion = models.ForeignKey(Ubicacion, on_delete=models.CASCADE)
    condicion_victima = models.ForeignKey(CondicionVictima, on_delete=models.CASCADE)
    gravedad_victima = models.ForeignKey(GravedadVictima, on_delete=models.CASCADE)
    tipo_accidente = models.ForeignKey(TipoAccidente, on_delete=models.CASCADE)
    sexo_victima = models.CharField(max_length=1, null=True, blank=True)
    edad_victima = models.PositiveSmallIntegerField()
    cantidad_victima = models.PositiveSmallIntegerField()
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    def _str_(self):
        return



CREATE TABLE rol (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(128) NOT NULL,
    primer_nombre VARCHAR(50) NOT NULL,
    segundo_nombre VARCHAR(50),
    primer_apellido VARCHAR(50) NOT NULL,
    segundo_apellido VARCHAR(50) NOT NULL,
    rol_id INT,
    email VARCHAR(254) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (rol_id) REFERENCES rol(id) ON DELETE CASCADE
);

CREATE TABLE zona (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE barrio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    zona_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (zona_id) REFERENCES zona(id) ON DELETE CASCADE
);

CREATE TABLE tipo_via (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE via (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_via_id INT,
    numero_via VARCHAR(5),
    nombre_via VARCHAR(50),
    sufijo_via VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tipo_via_id) REFERENCES tipo_via(id) ON DELETE CASCADE
);

CREATE TABLE ubicacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    primer_via_id INT NOT NULL,
    segunda_via_id INT,
    latitud DECIMAL(9, 6),
    longitud DECIMAL(9, 6),
    barrio_id INT,
    complemento VARCHAR(256),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (primer_via_id) REFERENCES via(id) ON DELETE CASCADE,
    FOREIGN KEY (segunda_via_id) REFERENCES via(id) ON DELETE CASCADE,
    FOREIGN KEY (barrio_id) REFERENCES barrio(id) ON DELETE CASCADE
);

CREATE TABLE condicion_victima (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rol_victima VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE gravedad_victima (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nivel_gravedad VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE tipo_accidente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE accidente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    ubicacion_id INT,
    condicion_victima_id INT,
    gravedad_victima_id INT,
    tipo_accidente_id INT,
    sexo_victima CHAR(1),
    edad_victima SMALLINT UNSIGNED,
    cantidad_victima SMALLINT UNSIGNED,
    usuario_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ubicacion_id) REFERENCES ubicacion(id) ON DELETE CASCADE,
    FOREIGN KEY (condicion_victima_id) REFERENCES condicion_victima(id) ON DELETE CASCADE,
    FOREIGN KEY (gravedad_victima_id) REFERENCES gravedad_victima(id) ON DELETE CASCADE,
    FOREIGN KEY (tipo_accidente_id) REFERENCES tipo_accidente(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE CASCADE
);