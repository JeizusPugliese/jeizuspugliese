import os
import mysql.connector

conn = mysql.connector.connect(
    host="bav268un6e2u3yehiri8-mysql.services.clever-cloud.com",
    port=3306,
    database="bav268un6e2u3yehiri8",
    user="uame0aibiei5vahb",
    password="WuEXsgrO5UJCTVpRirO7"
)
cursor = conn.cursor()

carpeta_imagenes = "C:/Users/manue/Downloads/Test/img"

if not os.path.exists(carpeta_imagenes):
    print("⚠ La carpeta no existe:", carpeta_imagenes)
    exit()

for archivo in os.listdir(carpeta_imagenes):
    ruta_completa = os.path.join(carpeta_imagenes, archivo)
    if archivo.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp")):
        try:
            with open(ruta_completa, 'rb') as f:
                binary_data = f.read()
            # Inserta el nombre original junto con el dato binario
            cursor.execute(
                "INSERT INTO test (filename, IMG) VALUES (%s, %s)",
                (archivo, binary_data)
            )
            conn.commit()
            print(f"✅ Imagen guardada en la base de datos: {archivo}")
        except Exception as e:
            print(f"❌ Error guardando {archivo}: {e}")

cursor.close()
conn.close()
